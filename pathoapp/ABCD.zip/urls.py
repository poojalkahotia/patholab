from django.urls import path
from pathoapp import views  # Importing all views
#from .views import viewurine, deleteurine, updateurine  # Explicitly importing specific views
#from .urinepdfreport import generate_urine_test_report  # Import the report generation function
from .views import generate_haematology_report ,generate_bloodsugar_report,generate_kidney_report,generate_urine_report,generate_hiv_report,generate_microalbumin_report # Import the function from views
from django.urls import path
from .views import *
from django.contrib.auth import views as auth_views
from .views import tests_on_date
from .views import ForgotPasswordView, ResetPasswordView
from django.contrib.auth import views as auth_views

urlpatterns = [ 
    path('', home, name='home'),  # This sets the home view as the root URL 
    path('login/', views.user_login, name='login'),
    path('password_change/', views.password_change, name='password_change'),
    path('forgot-password/', ForgotPasswordView.as_view(), name='forgot_password'),
    path('reset-password/<uidb64>/<token>/', ResetPasswordView.as_view(), name='reset_password'),              
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('about/', views.About, name='about'),
    path('contact/', views.Contact, name='contact'),
    #path('call-functions/', views.combined_view, name='call-functions'),
    path('fun/', views.function_one, name='fun'),
    path('adddoctor/', views.adddoctor, name='adddoctor'),
    path('delete/<str:doctorname>/', views.deletedoctor, name='deletedata'),
    path('get-doctor-email/', views.get_doctor_email, name='get_doctor_email'),  # URL for fetching doctor email
    path('doctor_st/', views.doctor_st, name='doctor_st'),
    #path('function-one/', views.function_one_view, name='function-one'),
    #path('function-two/', views.function_two_view, name='function-two'),
    #path('function-both/', views.both_functions_view, name='function-both'),
    path('function-one/', views.function_one_view, name='function-one'),          # Call Function 1
    path('function-two/', views.function_two_view, name='function-two'),          # Call Function 2
    path('call-both-functions/', views.call_both_functions_view, name='call-both-functions'),  # Call Both Functions


    path('addpatient/', views.addpatient, name='addpatient'),

    path('get_patient_data/', views.get_patient_data, name='get_patient_data'),
    path('viewpatient/', views.viewpatient, name='viewpatient'),
    path('updatepatient/<int:patientid>', views.updatepatient, name='updatepatient'),
    
    path('addhaematology/', views.addhaematology, name='addhaematology'),
    path('addhaematology/', views.addhaematology, name='addhaematology'),
    path('viewhaematology/', views.viewhaematology, name='viewhaematology'),
    path('updatehaematology/<str:test_id>/', views.updatehaematology, name='updatehaematology'),
    path('deletehaematology/<str:test_id>/', views.deletehaematology, name='deletehaematology'),
    path('haematology_report/<int:test_id>/', generate_haematology_report, name='generate_haematology_report'),
    path('getnexttestid_hae/', getnexttestid_hae, name='getnexttestid_hae'),
    
    path('addpathoinfo/', views.addpathoinfo, name='addpathoinfo'),
    
    path('test1/', views.handle_test1_submission, name='test1'),
    path('test2/', views.handle_test2_submission, name='test2'),
    path('test3/', views.handle_test3_submission, name='test3'),
    #path('test2/', views.handle_test2_submission, name='test2'),
    path('', views.Index, name='home'),
    
    path('addurine/', views.addurine, name='addurine'),
    path('viewurine/', views.viewurine, name='viewurine'),
    path('updateurine/<str:test_id>/', views.updateurine, name='updateurine'),
    path('deleteurine/<str:test_id>/', views.deleteurine, name='deleteurine'),
    path('urine_report/<int:test_id>/', generate_urine_report, name='generate_urine_report'),
    
    #path('send-pdf/', views.send_pdf_via_email, name='send_pdf_via_email'),
    #path('urine-test-report/<int:testid>/', generate_urine_test_report, name='urine_test_report'),  # URL for the report
    # Blood Sugar
    path('addbloodsugar/', views.addbloodsugar, name='addbloodsugar'),
    path('viewbloodsugar/', views.viewbloodsugar, name='viewbloodsugar'),
    path('updatebloodsugar/<str:test_id>/', views.updatebloodsugar, name='updatebloodsugar'),
    path('deletebloodsugar/<str:test_id>/', views.deletebloodsugar, name='deletebloodsugar'),
    path('bloodsugar_report/<int:test_id>/', generate_bloodsugar_report, name='generate_bloodsugar_report'),
    
    # Kidney
    path('addkidney/', views.addkidney, name='addkidney'),
    path('viewkidney/', views.viewkidney, name='viewkidney'),
    path('updatekidney/<str:test_id>/', views.updatekidney, name='updatekidney'),
    path('deletekidney/<str:test_id>/', views.deletekidney, name='deletekidney'),
    path('kidney_report/<int:test_id>/', generate_kidney_report, name='generate_kidney_report'),

    path('tests/<str:date>/', tests_on_date, name='tests_on_date'),
    path('tests/', tests_on_date, name='tests_on_date_default'),  # Default URL without date

    path('addhiv/', views.addhiv, name='addhiv'),
    path('viewhiv/', views.viewhiv, name='viewhiv'),
    path('updatehiv/<str:test_id>/', views.updatehiv, name='updatehiv'),
    path('deletehiv/<str:test_id>/', views.deletehiv, name='deletehiv'),
    path('hiv_report/<int:test_id>/', generate_hiv_report, name='generate_hiv_report'),
    
    path('addmicroalbumin/', views.addmicroalbumin, name='addmicroalbumin'),
    path('viewmicroalbumin/', views.viewmicroalbumin, name='viewmicroalbumin'),
    path('updatemicroalbumin/<str:test_id>/', views.updatemicroalbumin, name='updatemicroalbumin'),
    path('deletemicroalbumin/<str:test_id>/', views.deletemicroalbumin, name='deletemicroalbumin'),
    path('microalbumin_report/<int:test_id>/', generate_microalbumin_report, name='generate_microalbumin_report'),
    
    path('daily_report/', views.daily_report, name='daily_report'),
]

