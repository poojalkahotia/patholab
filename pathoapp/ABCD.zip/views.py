from django.shortcuts import render,redirect, HttpResponseRedirect, get_object_or_404
from . models import *
from . views import *
from django.http import HttpResponse
from .forms import *
from django.contrib import messages
from django.http import JsonResponse
from django.db.models import Q
from django.db.models import Max
import os
from django.core.mail import EmailMessage # email pdf
from django.conf import settings
from io import BytesIO  #email pdf 
from django.http import FileResponse

from reportlab.lib import colors
from reportlab.lib.pagesizes import letter #email pdf 
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image
from reportlab.lib.styles import getSampleStyleSheet

from django.utils import timezone

from django.core.mail import send_mail  #checkbox email
from django.urls import reverse_lazy  # login page

from django.contrib.auth.views import PasswordChangeView   #changepass
from django.contrib.messages.views import SuccessMessageMixin  #changepass
#from .urinepdfreport import generate_urine_test_report
from django.contrib.auth.decorators import login_required
# views.py

from django.contrib.auth.forms import UserCreationForm  #signup
from django.templatetags.static import static


from django.contrib.auth import authenticate, login,logout
from django.contrib.auth import update_session_auth_hash
from django.contrib.auth.decorators import login_required
from django.urls import reverse
from django.contrib.auth.tokens import default_token_generator
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.utils.encoding import force_bytes, force_str
from django.contrib.auth.models import User
from django.views import View  # Import the View class
from .forms import ForgotPasswordForm, ResetPasswordForm
from django.views.decorators.http import require_GET

class ForgotPasswordView(View):
    def get(self, request):
        form = ForgotPasswordForm()
        return render(request, 'pathoapp/forgot_password.html', {'form': form})

    def post(self, request):
        form = ForgotPasswordForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data['email']
            user = User.objects.filter(email=email).first()
            if user:
                # Generate token and send email
                token = default_token_generator.make_token(user)
                uid = urlsafe_base64_encode(force_bytes(user.pk))
                reset_url = request.build_absolute_uri(
                    reverse('reset_password', kwargs={'uidb64': uid, 'token': token})
                )
                subject = "Password Reset Request"
                message = f"Click the link below to reset your password:\n\n{reset_url}"
                send_mail(subject, message, settings.DEFAULT_FROM_EMAIL, [email])
                messages.success(request, "Password reset link has been sent to your email.")
            else:
                messages.error(request, "No user found with this email address.")
            return redirect('forgot_password')
        return render(request, 'pathoapp/forgot_password.html', {'form': form})

class ResetPasswordView(View):
    def get(self, request, uidb64, token):
        try:
            uid = force_str(urlsafe_base64_decode(uidb64))
            user = User.objects.get(pk=uid)
            if default_token_generator.check_token(user, token):
                form = ResetPasswordForm(user)
                return render(request, 'reset_password.html', {'form': form})
            else:
                messages.error(request, "Invalid or expired token.")
                return redirect('forgot_password')
        except (TypeError, ValueError, OverflowError, User.DoesNotExist):
            messages.error(request, "Invalid link.")
            return redirect('forgot_password')

    def post(self, request, uidb64, token):
        try:
            uid = force_str(urlsafe_base64_decode(uidb64))
            user = User.objects.get(pk=uid)
            if default_token_generator.check_token(user, token):
                form = ResetPasswordForm(user, request.POST)
                if form.is_valid():
                    form.save()
                    messages.success(request, "Your password has been reset successfully.")
                    return redirect('login')
                else:
                    return render(request, 'reset_password.html', {'form': form})
            else:
                messages.error(request, "Invalid or expired token.")
                return redirect('forgot_password')
        except (TypeError, ValueError, OverflowError, User.DoesNotExist):
            messages.error(request, "Invalid link.")
            return redirect('forgot_password')

def user_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('home')  # Redirect to home page after login
        else:
            messages.error(request, 'Invalid username or password.')
    return render(request, 'pathoapp/login.html')

@login_required
def password_change(request):
    if request.method == 'POST':
        old_password = request.POST.get('old_password')
        new_password1 = request.POST.get('new_password1')
        new_password2 = request.POST.get('new_password2')

        # Check if the old password is correct
        if not request.user.check_password(old_password):
            messages.error(request, 'Your old password was entered incorrectly. Please try again.')
            return redirect('password_change')

        # Check if new passwords match
        if new_password1 != new_password2:
            messages.error(request, 'The new passwords do not match. Please try again.')
            return redirect('password_change')

        # Change the password
        request.user.set_password(new_password1)
        request.user.save()

        # Update session to prevent logout
        update_session_auth_hash(request, request.user)

        messages.success(request, 'Your password has been changed successfully!')
        return redirect('home')

    return render(request, 'pathoapp/change_password.html')

def logout(request):
    logout(request)
    messages.success(request, 'You have been successfully logged out.')
    return redirect('home')

def home(request):
    return render(request, 'home.html')

def About(request):
    return render(request,'about.html')

def Contact(request):
    return render(request,'contact.html')

def Index(request):
    return render(request,'index.html')




# View to add a new doctor
def adddoctor(request):
    if request.method == 'POST':
        fm = DoctorForm(request.POST)
        if fm.is_valid():
           fm.save()
        messages.add_message(request, messages.SUCCESS, 'Data Saved Successfully !!!')
        fm = DoctorForm() #data save hone ke baad phir se blank form aa jaye isliye
            
    else:
        fm = DoctorForm()
    doctor = Doctor.objects.all()
    return render(request, 'adddoctor.html',{'form':fm, 'doc':doctor})

def deletedoctor(request, doctorname):  # Accept 'doctorname' as a parameter
    if request.method == 'POST':
        Doctor.objects.filter(doctorname=doctorname).delete()  # Filter by doctorname and delete
        messages.add_message(request, messages.SUCCESS, 'Doctor Deleted Successfully !!!')
    return redirect('adddoctor')  # Redirect to 'adddoctor' page after deletion




def get_doctor_email(request):
    doctor_name = request.GET.get('doctorname', None)  # Get doctorname from AJAX request

    if doctor_name:
        try:
            doctor = Doctor.objects.get(doctorname=doctor_name)  # Fetch doctor by name
            return JsonResponse({'email': doctor.email})  # Return email in JSON format
        except Doctor.DoesNotExist:
            return JsonResponse({'email': ''})  # Return empty string if doctor does not exist
    return JsonResponse({'email': ''})


def addpatient(request):
    doctors = Doctor.objects.all()  # Fetch all doctors for dropdown

    if request.method == 'POST':
        patientid = request.POST['patientid']
        patientname = request.POST['patientname']
        age = request.POST['age']
        gender = request.POST['gender']
        mobile = request.POST['mobile']
        email = request.POST['email']
        address = request.POST['address']
        recondate = request.POST['recondate']
        doctor_name = request.POST['refbydoctor']  # Get selected doctor from dropdown

        try:
            # Fetch doctor instance by doctorname (since it's the primary key)
            doctor = Doctor.objects.get(doctorname=doctor_name)

            # Create a new PatientMaster record
            PatientMaster.objects.create(
                patientid=patientid,
                patientname=patientname,
                age=age,
                gender=gender,
                mobile=mobile,
                email=email,
                address=address,
                recondate=recondate,
                refbydoctor=doctor  # Save doctor reference
            )
            messages.success(request, 'Patient added successfully!')
            return redirect('viewpatient')  # Redirect to view patient after saving
        except Doctor.DoesNotExist:
            messages.error(request, 'Selected doctor does not exist.')
            return render(request, 'addpatient.html', {'error': 'yes', 'doctors': doctors})
        except Exception as e:
            messages.error(request, 'Something went wrong, please try again.')
            return render(request, 'addpatient.html', {'error': 'yes', 'doctors': doctors})

    return render(request, 'addpatient.html', {'doctors': doctors, 'error': 'no'})

def viewpatient(request):
    # Fetch all patient records including related doctor details
    patients = PatientMaster.objects.select_related('refbydoctor').all()

    # Pass the patient data to the template
    context = {
        'patients': patients
    }
    return render(request, 'viewpatient.html', context)

def deletepatient(request, patientid):
       # Get the patient object, or return a 404 if not found
    patient_data = get_object_or_404(PatientMaster, patientid=patientid)

    if request.method == 'POST':
        # Delete the patient record
        patient_data.delete()
        messages.success(request, "Record deleted successfully!")
        return redirect('viewpatient')
    return redirect('viewpatient')

    # Render a confirmation template or redirect as needed
    return redirect('view_patient')





def updatepatient(request, patientid):
    # Get the patient instance
    patient = get_object_or_404(PatientMaster, patientid=patientid)
    doctors = Doctor.objects.all()  # Fetch all doctors for dropdown

    if request.method == 'POST':
        # Update patient data from form
        patient.patientname = request.POST['patientname']
        patient.recondate = request.POST['recondate']
        patient.age = request.POST['age']
        patient.gender = request.POST['gender']
        patient.mobile = request.POST['mobile']
        patient.email = request.POST['email']
        patient.address = request.POST['address']
        doctor_name = request.POST['refbydoctor']
        patient.refbydoctor = get_object_or_404(Doctor, doctorname=doctor_name)

        try:
            patient.save()  # Save updated patient information
            messages.success(request, 'Patient updated successfully!')
            return redirect('viewpatient')  # Redirect back to the view patient page
        except Exception as e:
            messages.error(request, f'Error: {str(e)}')

    # Render the update form with patient and doctor data
    return render(request, 'updatepatient.html', {'patient': patient, 'doctors': doctors})




# Function 1 logic
def function_one():
    print("Pradeep Function One Called")
    return "Pradeep Function One Called"  # Return a message for confirmation

# Function 2 logic
def function_two():
    print("Function Two Called")
    return "Function Two Called"  # Return a message for confirmation

def function_two():
    print("Function Two Called")
    return "Function Two Called"  # Return a message for confirmation


# View to call Function 1
def function_one_view(request):
    if request.method == 'GET':  # Ensure it works with a GET request
        message = function_one()  # Call Function One
        return JsonResponse({'message': message})
    return JsonResponse({'error': 'Invalid request method'}, status=400)

# View to call Function 2
def function_two_view(request):
    if request.method == 'GET':  # Ensure it works with a GET request
        message = function_two()  # Call Function Two
        return JsonResponse({'message': message})
    return JsonResponse({'error': 'Invalid request method'}, status=400)

# View to call Both Functions
def call_both_functions_view(request):
    if request.method == 'GET':  # Ensure it works with a GET request
        message_one = function_one()  # Call Function One
        message_two = function_two()  # Call Function Two
        return JsonResponse({'messages': [message_one, message_two]})
    return JsonResponse({'error': 'Invalid request method'}, status=400)

def addhaematology(request):
    # Get the next test ID for the Haematology test
    max_test_id = Haematology.objects.aggregate(Max('test_id'))['test_id__max']
    next_test_id = (max_test_id + 1) if max_test_id is not None else 1

    # Fetch all patients from the PatientMaster model
    patients = PatientMaster.objects.all()

    if request.method == 'POST':
        form = HaematologyForm(request.POST)
        if form.is_valid():
            patient_id = request.POST.get('patient_id')  # Get patient_id from the form
            doctor_name = request.POST.get('doctor')  # Get doctor name from the form

            try:
                # Fetch the PatientMaster instance using the patient_id
                patient = PatientMaster.objects.get(pk=patient_id)

                # Fetch the Doctor instance using the doctor name
                doctor = patient.refbydoctor  # Get the doctor from the patient's refbydoctor field

                # Create a Haematology instance without saving it yet
                haematology_test = form.save(commit=False)
                haematology_test.test_id = next_test_id
                haematology_test.patient = patient
                haematology_test.doctor = doctor  # Assign the doctor

                # Populate the Haematology instance with data from PatientMaster
                haematology_test.patientname = patient.patientname
                haematology_test.age = patient.age
                haematology_test.gender = patient.gender
                haematology_test.mobile = patient.mobile
                haematology_test.email = patient.email

                # Save the Haematology instance
                haematology_test.save()

                # Update the next_test_id for the form
                next_test_id += 1

                messages.success(request, 'Haematology test added successfully.')
                form = HaematologyForm(initial={'test_id': next_test_id})
                return render(request, 'addhaematology.html', {'form': form, 'next_test_id': next_test_id, 'patients': patients})
            except PatientMaster.DoesNotExist:
                messages.error(request, 'Patient ID not found.')
            except Exception as e:
                messages.error(request, f'An error occurred: {str(e)}')
    else:
        # For GET requests, initialize the form with the next_test_id
        form = HaematologyForm(initial={'test_id': next_test_id})

    return render(request, 'addhaematology.html', {'form': form, 'next_test_id': next_test_id, 'patients': patients})


@require_GET
def getnexttestid_hae(request):
    max_test_id = Haematology.objects.aggregate(Max('test_id'))['test_id__max']
    next_test_id = (max_test_id + 1) if max_test_id is not None else 1
    return JsonResponse({'next_test_id': next_test_id})

# Utility function to generate the PDF

def generate_haematology_pdf(haematology_test, buffer):
    pdf = SimpleDocTemplate(buffer, pagesize=letter)
    styles = getSampleStyleSheet()
    elements = []

    # Add Pathology Center Title
    title = Paragraph("Sur Pathology Station Road Durg", styles['Title'])
    elements.append(title)
    elements.append(Spacer(1, 12))

    # Add Pathology Logo if available
    logo_path = os.path.join(settings.BASE_DIR, 'pathoapp', 'static', 'images', 'logo.png')
    if os.path.exists(logo_path):
        logo = Image(logo_path, width=80, height=80)
        elements.append(logo)
        elements.append(Spacer(1, 12))

    # Add a horizontal line
    elements.append(Paragraph("<hr/>", styles['Normal']))
    elements.append(Spacer(1, 12))

    # Patient Information
    patient_info = [
        ["Patient Name:", haematology_test.patient.patientname],
        ["Age:", str(haematology_test.age)],
        ["Gender:", haematology_test.gender],
        ["Mobile:", haematology_test.mobile],
        ["Email:", haematology_test.email if haematology_test.email else "N/A"],
    ]
    patient_table = Table(patient_info, colWidths=[100, 200])
    patient_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 10),
    ]))
    elements.append(patient_table)
    elements.append(Spacer(1, 12))

    # Report Title
    report_title = Paragraph("Haematology Test Report", styles['Title'])
    elements.append(report_title)
    elements.append(Spacer(1, 12))

    # Test Details
    test_info = [
        ["Test ID:", str(haematology_test.test_id)],
        ["Test Date:", haematology_test.test_date.strftime("%Y-%m-%d") if haematology_test.test_date else "N/A"],
        ["Haemoglobin:", f"{haematology_test.haemoglobin} g/dL" if haematology_test.haemoglobin else "N/A"],
        ["RBC Count:", f"{haematology_test.rbc_count} million/μL" if haematology_test.rbc_count else "N/A"],
        ["Platelets:", f"{haematology_test.platelets} /μL" if haematology_test.platelets else "N/A"],
        ["PCV:", f"{haematology_test.pcv} %" if haematology_test.pcv else "N/A"],
        ["MCV:", f"{haematology_test.mcv} fL" if haematology_test.mcv else "N/A"],
        ["MCH:", f"{haematology_test.mch} pg" if haematology_test.mch else "N/A"],
        ["MCHC:", f"{haematology_test.mchc} g/dL" if haematology_test.mchc else "N/A"],
        ["Reticulocyte Count:", f"{haematology_test.reticulocyte_count} %" if haematology_test.reticulocyte_count else "N/A"],
        ["Bleeding Time:", f"{haematology_test.bleeding_time} min" if haematology_test.bleeding_time else "N/A"],
        ["Clotting Time:", f"{haematology_test.clotting_time} min" if haematology_test.clotting_time else "N/A"],
        ["Eosinophil Exam:", haematology_test.eosinophil_exam if haematology_test.eosinophil_exam else "N/A"],
        ["Sickling Exam:", haematology_test.sickling_exam if haematology_test.sickling_exam else "N/A"],
        ["Other Test:", haematology_test.other_test if haematology_test.other_test else "N/A"],
        ["Result:", haematology_test.result if haematology_test.result else "N/A"],
        ["Normal Value:", haematology_test.normal_value if haematology_test.normal_value else "Refer to specifics"],
        ["Remarks:", haematology_test.remarks if haematology_test.remarks else "None"],
    ]
    test_table = Table(test_info, colWidths=[150, 250])
    test_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 10),
    ]))
    elements.append(test_table)
    elements.append(Spacer(1, 12))

    # Signature Section
    elements.append(Spacer(1, 20))
    elements.append(Paragraph("Signature:", styles['Normal']))
    elements.append(Spacer(1, 40))

    # Generate PDF
    pdf.build(elements)



def viewhaematology(request):
    # Fetch all Haematology tests from the database
    haematology_tests = Haematology.objects.all()

    # Pass the test data to the template for rendering
    return render(request, 'viewhaematology.html', {
        'haematology_tests': haematology_tests
    })

def updatehaematology(request, test_id):
    # Fetch the Haematology test instance or show a 404 page if not found
    haematology_test = get_object_or_404(Haematology, test_id=test_id)

    if request.method == 'POST':
        # Bind form to POST data
        form = HaematologyForm(request.POST, instance=haematology_test)
        if form.is_valid():
            # Save the updated test if the form is valid
            form.save()
            messages.success(request, 'Data Updated Successfully.')
            return redirect('viewhaematology')
        else:
            # Add form errors to the context for debugging
            messages.error(request, 'Please correct the errors below.')
            print("Form Errors:", form.errors)  # Debugging information
    else:
        # Pre-populate the form with existing instance data
        form = HaematologyForm(instance=haematology_test)

    # Fetch the patient information from the PatientMaster associated with the Haematology test
    patient_data = haematology_test.patient  # Get the associated PatientMaster instance

    # Pre-fill the form with the patient's ID (as this can be changed)
    form.fields['patient_id'].initial = patient_data.patientid  # Assign initial patient ID value
    
    # Fetch additional data (refbydoctor and doctor_email) from PatientMaster
    patient_data.refbydoctor = patient_data.refbydoctor  # Fetch referred doctor name
    patient_data.email = patient_data.email  # Fetch doctor email

    # Render the update form template with the form and patient data
    return render(request, 'updatehaematology.html', {
        'form': form,
        'test_id': test_id,
        'patient_data': patient_data  # Pass the patient data to the template
    })


def deletehaematology(request, test_id):
    # Get the Haematology test record to be deleted
    haematology_test = get_object_or_404(Haematology, test_id=test_id)
    
    # Delete the record
    haematology_test.delete()
    
    # Add a success message
    messages.success(request, 'Haematology test deleted successfully.')
    
    # Redirect to the view page
    return redirect('viewhaematology')




def get_patient_data(request):
    patient_id = request.GET.get('patient_id')
    if patient_id:
        try:
            # Fetch the patient record
            patient = PatientMaster.objects.get(pk=patient_id)
            
            # Fetch the referring doctor's email (if any)
            doctor_email = patient.refbydoctor.email if patient.refbydoctor else None
            
            # Prepare the response data
            data = {
                'patientname': patient.patientname,
                'age': patient.age,
                'gender': patient.gender,
                'mobile': patient.mobile,
                'email': patient.email,  # Patient's email
                'doctorname': patient.refbydoctor.doctorname if patient.refbydoctor else None,
                'doctoremail': doctor_email,  # Referring doctor's email
            }
            return JsonResponse(data)
        except PatientMaster.DoesNotExist:
            return JsonResponse({'error': 'Patient not found'}, status=404)
    return JsonResponse({'error': 'Invalid request'}, status=400)







def generate_haematology_report(request, test_id):
    # Fetch the haematology record using the test_id
    try:
        haematology_test = Haematology.objects.get(test_id=test_id)
    except Haematology.DoesNotExist:
        return HttpResponse("Haematology test not found.", content_type='text/plain')

    # Fetch the pathology center information
    pathology_info = Pathoinfo.objects.first()

    # Create a PDF response
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="haematology_report_{test_id}.pdf"'

    # Create a PDF document
    pdf = SimpleDocTemplate(response, pagesize=letter)
    styles = getSampleStyleSheet()
    elements = []

    # Add logo with reduced size
    logo_path = os.path.join(settings.BASE_DIR, 'pathoapp', 'static', 'images', 'logo.jpeg')
    if os.path.exists(logo_path):
        logo = Image(logo_path, width=100, height=100)  # Reduced size
        elements.append(logo)
    else:
        elements.append(Paragraph("Logo image not found", styles['Normal']))

    # Add pathology center information, single centered table
    if pathology_info:
        pathology_info_data = [
            [pathology_info.name],
            [f"Address: {pathology_info.add1}, {pathology_info.add2}, {pathology_info.city}"],
            [f"Mobile: {pathology_info.mobile}"],
            [f"Terms: {pathology_info.term1}"],
        ]
        pathology_table = Table(pathology_info_data, colWidths=[400])
        pathology_table.setStyle(TableStyle([
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 12),  # Reduced font size
            ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
            ('TOPPADDING', (0, 0), (-1, -1), 3),
        ]))
        elements.append(pathology_table)
    else:
        elements.append(Paragraph("Pathology Center Information Not Available", styles['Normal']))

    elements.append(Spacer(1, 8))

    # Patient details in a single-row table with compact spacing
    patient_info = [
        ["Test ID", "Test Date", "Patient Name", "Age", "Mobile", ],
        [str(haematology_test.test_id),haematology_test.test_date,haematology_test.patient.patientname,  haematology_test.age, 
         haematology_test.mobile, ]
    ]
    patient_table = Table(patient_info, colWidths=[60, 100, 100, 60, 80])
    patient_table.setStyle(TableStyle([
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
        ('FONTSIZE', (0, 0), (-1, -1), 12),  # Smaller font for compactness
        ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
        ('GRID', (0, 0), (-1, -1), 0.3, colors.grey),
    ]))
    elements.append(patient_table)

    elements.append(Spacer(1, 8))

    # Report title with a smaller font size
    report_title = Paragraph("Haematology Test Report", styles['Title'])
    report_title.style.fontSize = 14  # Slightly reduced font size
    elements.append(report_title)
    elements.append(Spacer(1, 8))

    # Haematology test details in a three-column layout
    test_info = [
        ["Investigation", "Patient's Value", "Normal Value"],
        ["Haemoglobin", str(haematology_test.haemoglobin), "Male: 13-17 g/dL, Female: 12-15 g/dL"],
        ["RBC Count", str(haematology_test.rbc_count), "Male: 4.7-6.1 million/μL, Female: 4.2-5.4 million/μL"],
        ["Platelets", str(haematology_test.platelets), "150,000-450,000 /μL"],
        ["PCV", str(haematology_test.pcv), "Male: 40-54%, Female: 36-48%"],
        ["MCV", str(haematology_test.mcv), "80-100 fL"],
        ["MCH", str(haematology_test.mch), "27-31 pg"],
        ["MCHC", str(haematology_test.mchc), "32-36 g/dL"],
        ["Reticulocyte Count", str(haematology_test.reticulocyte_count), "0.5-2.5%"],
        ["Bleeding Time", str(haematology_test.bleeding_time), "2-7 min"],
        ["Clotting Time", str(haematology_test.clotting_time), "4-10 min"],
        ["Eosinophil Exam", str(haematology_test.eosinophil_exam), "Normal: < 5%"],
        ["Sickling Exam", haematology_test.sickling_exam, "Negative"],
        ["Other Test", haematology_test.other_test, "Refer to specifics"],
        ["Result", haematology_test.result, "Refer to specifics"],
        ["Remarks", haematology_test.remarks, "N/A"],
    ]

    test_table = Table(test_info, colWidths=[130, 100, 280])
    test_table.setStyle(TableStyle([
        ('ALIGN', (0, 0), (-1, 0), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
        ('FONTSIZE', (0, 0), (-1, -1), 12),  # Reduced font size for test details
        ('GRID', (0, 0), (-1, -1), 0.3, colors.grey),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
    ]))
    elements.append(test_table)

    elements.append(Spacer(1, 8))

    # Signature section
       # Signature section aligned to the right
    signature_data = [
        ["", "Signature"]  # Empty cell on the left and "Signature" on the right
    ]
    signature_table = Table(signature_data, colWidths=[400, 100])  # Adjust the width as necessary
    signature_table.setStyle(TableStyle([
        ('ALIGN', (1, 0), (1, 0), 'RIGHT'),  # Align "Signature" text to the right
        ('FONTNAME', (1, 0), (1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (1, 0), (1, 0), 20),  # Set font size for "Signature"
        ('TOPPADDING', (0, 0), (-1, -1), 20),  # Add padding at the top for space
    ]))

    # Add the signature table to elements
    elements.append(signature_table)
    # Build the PDF
    pdf.build(elements)
    return response

def addpathoinfo(request):
    if request.method == "POST":
        form = PathoinfoForm(request.POST)
        if form.is_valid():
            form.save()  # Save the data to the database
            messages.success(request, "Pathoinfo has been added successfully.")
            return redirect('addpathoinfo')  # Redirect to the same page or another page
        else:
            messages.error(request, "Please correct the errors below.")
    else:
        form = PathoinfoForm()
    
    context = {
        'form': form
    }
    return render(request, 'addpathoinfo.html', context)
        
        

def test1(request):
    return render(request,'test1.html')

def test2(request):
    return render(request,'test2.html')

def test3(request):
    return render(request,'test3.html')

  
def handle_test1_submission(request):
    if request.method == 'POST' and 'submit_button1' in request.POST:
        # Process the form data for Form 1
        # ...
        return render(request,'addpatient.html') 
    else:
        return render(request, 'test1.html')  # Render the test1 page

def handle_test2_submission(request):
    if request.method == 'POST' and 'submit_button2' in request.POST:
        # Process the form data for Form 2
        return render(request,'test3.html') 
    else:
        return render(request, 'test2.html')  # Render the test1 page
  
     
def handle_test3_submission(request):
    if request.method == 'POST' and 'submit_button3' in request.POST:
        # Process the form data for Form 1
        # ...
        return render(request,'addpatient.html') 
    else:
        return render(request, 'about.html')  # Render the test1 page


def addbloodsugar(request):
    # Get the next test ID for the BloodSugar test
    max_test_id = BloodSugar.objects.aggregate(Max('test_id'))['test_id__max']
    next_test_id = (max_test_id + 1) if max_test_id is not None else 1

    # Fetch all patients from the PatientMaster model
    patients = PatientMaster.objects.all()

    if request.method == 'POST':
        form = BloodSugarForm(request.POST)
        if form.is_valid():
            patient_id = request.POST.get('patient_id')  # Get patient_id from the form
            try:
                # Fetch the PatientMaster instance using the patient_id
                patient = PatientMaster.objects.get(pk=patient_id)

                # Fetch the Doctor instance from the patient's refbydoctor field
                doctor = patient.refbydoctor  # Get the doctor from the patient's refbydoctor field

                # Create a BloodSugar instance without saving it yet
                bloodsugar_test = form.save(commit=False)
                bloodsugar_test.test_id = next_test_id
                bloodsugar_test.patient = patient
                bloodsugar_test.doctor = doctor  # Assign the doctor

                # Populate the BloodSugar instance with data from PatientMaster
                bloodsugar_test.patientname = patient.patientname
                bloodsugar_test.age = patient.age
                bloodsugar_test.gender = patient.gender
                bloodsugar_test.mobile = patient.mobile
                bloodsugar_test.email = patient.email

                # Save the BloodSugar instance
                bloodsugar_test.save()

                # Update the next_test_id for the form
                next_test_id += 1

                messages.success(request, 'Blood Sugar test added successfully.')
                form = BloodSugarForm(initial={'test_id': next_test_id})
                return render(request, 'addbloodsugar.html', {'form': form, 'next_test_id': next_test_id, 'patients': patients})
            except PatientMaster.DoesNotExist:
                messages.error(request, 'Patient ID not found.')
            except Exception as e:
                messages.error(request, f'An error occurred: {str(e)}')
    else:
        # For GET requests, initialize the form with the next_test_id
        form = BloodSugarForm(initial={'test_id': next_test_id})

    return render(request, 'addbloodsugar.html', {'form': form, 'next_test_id': next_test_id, 'patients': patients})


# Utility function to generate the PDF

def generate_bloodsugar_pdf(bloodsugar_test, buffer):
    pdf = SimpleDocTemplate(buffer, pagesize=letter)
    styles = getSampleStyleSheet()
    elements = []

    # Add Pathology Center Title
    title = Paragraph("Sur Pathology Station Road Durg", styles['Title'])
    elements.append(title)
    elements.append(Spacer(1, 12))

    # Add Pathology Logo if available
    logo_path = os.path.join(settings.BASE_DIR, 'pathoapp', 'static', 'images', 'logo.png')
    if os.path.exists(logo_path):
        logo = Image(logo_path, width=80, height=80)
        elements.append(logo)
        elements.append(Spacer(1, 12))

    # Add a horizontal line
    elements.append(Paragraph("<hr/>", styles['Normal']))
    elements.append(Spacer(1, 12))

    # Patient Information
    patient_info = [
        ["Patient Name:", bloodsugar_test.patient.patientname],
        ["Age:", str(bloodsugar_test.age)],
        ["Gender:", bloodsugar_test.gender],
        ["Mobile:", bloodsugar_test.mobile],
        ["Email:", bloodsugar_test.email if bloodsugar_test.email else "N/A"],
    ]
    patient_table = Table(patient_info, colWidths=[100, 200])
    patient_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 10),
    ]))
    elements.append(patient_table)
    elements.append(Spacer(1, 12))

    # Report Title
    report_title = Paragraph("bloodsugar Test Report", styles['Title'])
    elements.append(report_title)
    elements.append(Spacer(1, 12))

    # Test Details
    test_info = [
        ["Test ID:", str(bloodsugar_test.test_id)],
        ["Test Date:", bloodsugar_test.test_date.strftime("%Y-%m-%d") if bloodsugar_test.test_date else "N/A"],
        ["Blood Sugar(Fasting):", f"{bloodsugar_test.bloodfas} g/dL" if bloodsugar_test.bloodfas else "N/A"],
        ["Blood Sugar(PP):", f"{bloodsugar_test.bloodpp} million/μL" if bloodsugar_test.bloodpp else "N/A"],
        ["Blood Sugar(Random):", f"{bloodsugar_test.bloodrandom} /μL" if bloodsugar_test.bloodrandom else "N/A"],
        ["Urine Sugar(Fasting):", f"{bloodsugar_test.urinefas} %" if bloodsugar_test.urinefas else "N/A"],
        ["Urine Sugar(PP):", f"{bloodsugar_test.urinepp} fL" if bloodsugar_test.urinepp else "N/A"],
        ["Urine Sugar(Random):", f"{bloodsugar_test.urinerandom} pg" if bloodsugar_test.urinerandom else "N/A"],
        ["Acetone:", f"{bloodsugar_test.acetone} g/dL" if bloodsugar_test.acetone else "N/A"],
        ["Other Test:", bloodsugar_test.other_test if bloodsugar_test.other_test else "N/A"],
        ["Result:", bloodsugar_test.result if bloodsugar_test.result else "N/A"],
        ["Normal Value:", bloodsugar_test.normal_value if bloodsugar_test.normal_value else "Refer to specifics"],
        ["Remarks:", bloodsugar_test.remarks if bloodsugar_test.remarks else "None"],
    ]
    test_table = Table(test_info, colWidths=[150, 250])
    test_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 10),
    ]))
    elements.append(test_table)
    elements.append(Spacer(1, 12))

    # Signature Section
    elements.append(Spacer(1, 20))
    elements.append(Paragraph("Signature:", styles['Normal']))
    elements.append(Spacer(1, 40))

    # Generate PDF
    pdf.build(elements)





def viewbloodsugar(request):
    # Fetch all bloodsugar tests from the database
    bloodsugar_tests = BloodSugar.objects.all()

    # Pass the test data to the template for rendering
    return render(request, 'viewbloodsugar.html', {
        'bloodsugar_tests': bloodsugar_tests
    })

def updatebloodsugar(request, test_id):
    # Fetch the bloodsugar test instance or show a 404 page if not found
    bloodsugar_test = get_object_or_404(BloodSugar, test_id=test_id)

    if request.method == 'POST':
        # Bind form to POST data
        form = BloodSugarForm(request.POST, instance=bloodsugar_test)
        if form.is_valid():
            # Save the updated test if the form is valid
            form.save()
            messages.success(request, 'Data Updated Successfully.')
            return redirect('viewbloodsugar')
        else:
            # Add form errors to the context for debugging
            messages.error(request, 'Please correct the errors below.')
            print("Form Errors:", form.errors)  # Debugging information
    else:
        # Pre-populate the form with existing instance data
        form = BloodSugarForm(instance=bloodsugar_test)

    # Fetch the patient information from the PatientMaster associated with the bloodsugar test
    patient_data = bloodsugar_test.patient  # Get the associated PatientMaster instance

    # Pre-fill the form with the patient's ID (as this can be changed)
    form.fields['patient_id'].initial = patient_data.patientid  # Assign initial patient ID value
    
    # Fetch additional data (refbydoctor and doctor_email) from PatientMaster
    patient_data.refbydoctor = patient_data.refbydoctor  # Fetch referred doctor name
    patient_data.email = patient_data.email  # Fetch doctor email

    # Render the update form template with the form and patient data
    return render(request, 'updatebloodsugar.html', {
        'form': form,
        'test_id': test_id,
        'patient_data': patient_data  # Pass the patient data to the template
    })


def deletebloodsugar(request, test_id):
    # Get the bloodsugar test record to be deleted
    bloodsugar_test = get_object_or_404(BloodSugar, test_id=test_id)
    
    # Delete the record
    bloodsugar_test.delete()
    
    # Add a success message
    messages.success(request, 'BloodSugar test deleted successfully.')
    
    # Redirect to the view page
    return redirect('viewbloodsugar')


def generate_bloodsugar_report(request, test_id):
   # Fetch the bloodsugar record using the test_id
    try:
        bloodsugar_test = BloodSugar.objects.get(test_id=test_id)
    except BloodSugar.DoesNotExist:
        return HttpResponse("BloodSugar test not found.", content_type='text/plain')

    # Fetch the pathology center information
    pathology_info = Pathoinfo.objects.first()

    # Create a PDF response
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="bloodsugar_report_{test_id}.pdf"'

    # Create a PDF document
    pdf = SimpleDocTemplate(response, pagesize=letter)
    styles = getSampleStyleSheet()
    elements = []

    # Add logo with reduced size
    logo_path = os.path.join(settings.BASE_DIR, 'pathoapp', 'static', 'images', 'logo.png')
    if os.path.exists(logo_path):
        logo = Image(logo_path, width=80, height=80)  # Reduced size
        elements.append(logo)
    else:
        elements.append(Paragraph("Logo image not found", styles['Normal']))

    # Add pathology center information, single centered table
    if pathology_info:
        pathology_info_data = [
            [pathology_info.name],
            [f"Address: {pathology_info.add1}, {pathology_info.add2}, {pathology_info.city}"],
            [f"Mobile: {pathology_info.mobile}"],
            [f"Terms: {pathology_info.term1}"],
        ]
        pathology_table = Table(pathology_info_data, colWidths=[400])
        pathology_table.setStyle(TableStyle([
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 12),  # Reduced font size
            ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
            ('TOPPADDING', (0, 0), (-1, -1), 3),
        ]))
        elements.append(pathology_table)
    else:
        elements.append(Paragraph("Pathology Center Information Not Available", styles['Normal']))

    elements.append(Spacer(1, 8))

    # Patient details in a single-row table with compact spacing
    patient_info = [
        ["Test ID", "Test Date", "Patient Name", "Age", "Mobile", ],
        [str(bloodsugar_test.test_id),bloodsugar_test.test_date,bloodsugar_test.patient.patientname,  bloodsugar_test.age, 
         bloodsugar_test.mobile, ]
    ]
    patient_table = Table(patient_info, colWidths=[60, 100, 100, 60, 80])
    patient_table.setStyle(TableStyle([
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
        ('FONTSIZE', (0, 0), (-1, -1), 12),  # Smaller font for compactness
        ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
        ('GRID', (0, 0), (-1, -1), 0.3, colors.grey),
    ]))
    elements.append(patient_table)

    elements.append(Spacer(1, 8))

    # Report title with a smaller font size
    report_title = Paragraph("Blood Sugar Test Report", styles['Title'])
    report_title.style.fontSize = 14  # Slightly reduced font size
    elements.append(report_title)
    elements.append(Spacer(1, 8))

    # Blood Sugar test details in a three-column layout
    test_info = [
        ["Investigation", "Patient's Value", "Normal Value"],
        ["Blood Sugar(Fasting)", str(bloodsugar_test.bloodfas), "Male: 13-17 g/dL, Female: 12-15 g/dL"],
        ["Blood Sugar(PP)", str(bloodsugar_test.bloodpp), "Male: 4.7-6.1 million/μL, Female: 4.2-5.4 million/μL"],
        ["Blood Sugar(Random)", str(bloodsugar_test.bloodrandom), "150,000-450,000 /μL"],
        ["Urine Sugar(Fasting)", str(bloodsugar_test.urinefas), "Male: 40-54%, Female: 36-48%"],
       
        ["Urine Sugar(PP)", str(bloodsugar_test.urinepp), "27-31 pg"],
        ["Urine Sugar(Random)", str(bloodsugar_test.urinerandom), "32-36 g/dL"],
        ["Acetone", str(bloodsugar_test.acetone), "0.5-2.5%"],
       
        ["Other Test", bloodsugar_test.other_test, "Refer to specifics"],
        ["Result", bloodsugar_test.result, "Refer to specifics"],
        ["Remarks", bloodsugar_test.remarks, "N/A"],
    ]

    test_table = Table(test_info, colWidths=[130, 100, 280])
    test_table.setStyle(TableStyle([
        ('ALIGN', (0, 0), (-1, 0), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
        ('FONTSIZE', (0, 0), (-1, -1), 12),  # Reduced font size for test details
        ('GRID', (0, 0), (-1, -1), 0.3, colors.grey),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
    ]))
    elements.append(test_table)

    elements.append(Spacer(1, 8))

    # Signature section
       # Signature section aligned to the right
    signature_data = [
        ["", "Signature"]  # Empty cell on the left and "Signature" on the right
    ]
    signature_table = Table(signature_data, colWidths=[400, 100])  # Adjust the width as necessary
    signature_table.setStyle(TableStyle([
        ('ALIGN', (1, 0), (1, 0), 'RIGHT'),  # Align "Signature" text to the right
        ('FONTNAME', (1, 0), (1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (1, 0), (1, 0), 20),  # Set font size for "Signature"
        ('TOPPADDING', (0, 0), (-1, -1), 20),  # Add padding at the top for space
    ]))

    # Add the signature table to elements
    elements.append(signature_table)


    # Build the PDF
    pdf.build(elements)

    return response


# View to add Kidney Test
def addkidney(request):
     # Get the next test ID for the Kidney test
    max_test_id = Kidney.objects.aggregate(Max('test_id'))['test_id__max']
    next_test_id = (max_test_id + 1) if max_test_id is not None else 1

    # Fetch all patients from the PatientMaster model
    patients = PatientMaster.objects.all()

    if request.method == 'POST':
        form = KidneyForm(request.POST)
        if form.is_valid():
            patient_id = request.POST.get('patient_id')  # Get patient_id from the form
            try:
                # Fetch the PatientMaster instance using the patient_id
                patient = PatientMaster.objects.get(pk=patient_id)

                # Fetch the Doctor instance from the patient's refbydoctor field
                doctor = patient.refbydoctor  # Get the doctor from the patient's refbydoctor field

                # Create a Kidney instance without saving it yet
                kidney_test = form.save(commit=False)
                kidney_test.test_id = next_test_id
                kidney_test.patient = patient
                kidney_test.doctor = doctor  # Assign the doctor

                # Populate the Kidney instance with data from PatientMaster
                kidney_test.patientname = patient.patientname
                kidney_test.age = patient.age
                kidney_test.gender = patient.gender
                kidney_test.mobile = patient.mobile
                kidney_test.email = patient.email

                # Save the Kidney instance
                kidney_test.save()

                # Update the next_test_id for the form
                next_test_id += 1

                messages.success(request, 'Kidney test added successfully.')
                form = KidneyForm(initial={'test_id': next_test_id})
                return render(request, 'addkidney.html', {'form': form, 'next_test_id': next_test_id, 'patients': patients})
            except PatientMaster.DoesNotExist:
                messages.error(request, 'Patient ID not found.')
            except Exception as e:
                messages.error(request, f'An error occurred: {str(e)}')
    else:
        # For GET requests, initialize the form with the next_test_id
        form = KidneyForm(initial={'test_id': next_test_id})

    return render(request, 'addkidney.html', {'form': form, 'next_test_id': next_test_id, 'patients': patients})



# Utility function to generate the PDF

def generate_kidney_pdf(kidney_test, buffer):
    pdf = SimpleDocTemplate(buffer, pagesize=letter)
    styles = getSampleStyleSheet()
    elements = []

    # Add Pathology Center Title
    title = Paragraph("Sur Pathology Station Road Durg", styles['Title'])
    elements.append(title)
    elements.append(Spacer(1, 12))

    # Add Pathology Logo if available
    logo_path = os.path.join(settings.BASE_DIR, 'pathoapp', 'static', 'images', 'logo.png')
    if os.path.exists(logo_path):
        logo = Image(logo_path, width=80, height=80)
        elements.append(logo)
        elements.append(Spacer(1, 12))

    # Add a horizontal line
    elements.append(Paragraph("<hr/>", styles['Normal']))
    elements.append(Spacer(1, 12))

    # Patient Information
    patient_info = [
        ["Patient Name:", kidney_test.patient.patientname],
        ["Age:", str(kidney_test.age)],
        ["Gender:", kidney_test.gender],
        ["Mobile:", kidney_test.mobile],
        ["Email:", kidney_test.email if kidney_test.email else "N/A"],
    ]
    patient_table = Table(patient_info, colWidths=[100, 200])
    patient_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 10),
    ]))
    elements.append(patient_table)
    elements.append(Spacer(1, 12))

    # Report Title
    report_title = Paragraph("kidney Test Report", styles['Title'])
    elements.append(report_title)
    elements.append(Spacer(1, 12))

    # Test Details
    test_info = [
        ["Test ID:", str(kidney_test.test_id)],
        ["Test Date:", kidney_test.test_date.strftime("%Y-%m-%d") if kidney_test.test_date else "N/A"],
        ["Bloodurea", str(kidney_test.bloodurea) if kidney_test.bloodurea else "N/A" ],
        ["Serumcreatinine", str(kidney_test.serumcreatinine)if kidney_test.serumcreatinine else "N/A"],
        ["Bun", str(kidney_test.bun)if kidney_test.bun else "N/A" ],
        ["Uricacid", str(kidney_test.uricacid)if kidney_test.uricacid else "N/A" ],
        ["Other Test", kidney_test.other_test if kidney_test.other_test else "N/A"],
        ["Result", kidney_test.result if kidney_test.result else "N/A" ],
        ["Normal_Value", str(kidney_test.normal_value)if kidney_test.normal_value else "N/A"],
        ["Remarks:", kidney_test.remarks if kidney_test.remarks else "None"],
    ]
    test_table = Table(test_info, colWidths=[150, 250])
    test_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 10),
    ]))
    elements.append(test_table)
    elements.append(Spacer(1, 12))

    # Signature Section
    elements.append(Spacer(1, 20))
    elements.append(Paragraph("Signature:", styles['Normal']))
    elements.append(Spacer(1, 40))

    # Generate PDF
    pdf.build(elements)



def viewkidney(request):
    # Fetch all kidney tests from the database
    kidney_tests = Kidney.objects.all()

    # Pass the test data to the template for rendering
    return render(request, 'viewkidney.html', {
        'kidney_tests': kidney_tests
    })

def updatekidney(request, test_id):
    # Fetch the kidney test instance or show a 404 page if not found
    kidney_test = get_object_or_404(Kidney, test_id=test_id)

    if request.method == 'POST':
        # Bind form to POST data
        form = KidneyForm(request.POST, instance=kidney_test)
        if form.is_valid():
            # Save the updated test if the form is valid
            form.save()
            messages.success(request, 'Data Updated Successfully.')
            return redirect('viewkidney')
        else:
            # Add form errors to the context for debugging
            messages.error(request, 'Please correct the errors below.')
            print("Form Errors:", form.errors)  # Debugging information
    else:
        # Pre-populate the form with existing instance data
        form = KidneyForm(instance=kidney_test)

    # Fetch the patient information from the PatientMaster associated with the Kidney test
    patient_data = kidney_test.patient  # Get the associated PatientMaster instance

    # Pre-fill the form with the patient's ID (as this can be changed)
    form.fields['patient_id'].initial = patient_data.patientid  # Assign initial patient ID value
    
    # Fetch additional data (refbydoctor and doctor_email) from PatientMaster
    patient_data.refbydoctor = patient_data.refbydoctor  # Fetch referred doctor name
    patient_data.email = patient_data.email  # Fetch doctor email

    # Render the update form template with the form and patient data
    return render(request, 'updatekidney.html', {
        'form': form,
        'test_id': test_id,
        'patient_data': patient_data  # Pass the patient data to the template
    })


def deletekidney(request, test_id):
    # Get the kidney test record to be deleted
    kidney_test = get_object_or_404(Kidney, test_id=test_id)
    
    # Delete the record
    kidney_test.delete()
    
    # Add a success message
    messages.success(request, 'kidney test deleted successfully.')
    
    # Redirect to the view page
    return redirect('viewkidney')


def generate_kidney_report(request, test_id):
   # Fetch the kidney record using the test_id
    try:
        kidney_test = Kidney.objects.get(test_id=test_id)
    except Kidney.DoesNotExist:
        return HttpResponse("Kidney test not found.", content_type='text/plain')

    # Fetch the pathology center information
    pathology_info = Pathoinfo.objects.first()

    # Create a PDF response
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="kidney_report_{test_id}.pdf"'

    # Create a PDF document
    pdf = SimpleDocTemplate(response, pagesize=letter)
    styles = getSampleStyleSheet()
    elements = []

    # Add logo with reduced size
    logo_path = os.path.join(settings.BASE_DIR, 'pathoapp', 'static', 'images', 'logo.png')
    if os.path.exists(logo_path):
        logo = Image(logo_path, width=80, height=80)  # Reduced size
        elements.append(logo)
    else:
        elements.append(Paragraph("Logo image not found", styles['Normal']))

    # Add pathology center information, single centered table
    if pathology_info:
        pathology_info_data = [
            [pathology_info.name],
            [f"Address: {pathology_info.add1}, {pathology_info.add2}, {pathology_info.city}"],
            [f"Mobile: {pathology_info.mobile}"],
            [f"Terms: {pathology_info.term1}"],
        ]
        pathology_table = Table(pathology_info_data, colWidths=[400])
        pathology_table.setStyle(TableStyle([
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 12),  # Reduced font size
            ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
            ('TOPPADDING', (0, 0), (-1, -1), 3),
        ]))
        elements.append(pathology_table)
    else:
        elements.append(Paragraph("Pathology Center Information Not Available", styles['Normal']))

    elements.append(Spacer(1, 8))

    # Patient details in a single-row table with compact spacing
    patient_info = [
        ["Test ID", "Test Date", "Patient Name", "Age", "Mobile", ],
        [str(kidney_test.test_id),kidney_test.test_date,kidney_test.patient.patientname,  kidney_test.age, 
         kidney_test.mobile, ]
    ]
    patient_table = Table(patient_info, colWidths=[60, 100, 100, 60, 80])
    patient_table.setStyle(TableStyle([
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
        ('FONTSIZE', (0, 0), (-1, -1), 12),  # Smaller font for compactness
        ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
        ('GRID', (0, 0), (-1, -1), 0.3, colors.grey),
    ]))
    elements.append(patient_table)

    elements.append(Spacer(1, 8))

    # Report title with a smaller font size
    report_title = Paragraph("Blood Sugar Test Report", styles['Title'])
    report_title.style.fontSize = 14  # Slightly reduced font size
    elements.append(report_title)
    elements.append(Spacer(1, 8))

    # Blood Sugar test details in a three-column layout
    test_info = [
        ["Investigation", "Patient's Value", "Normal Value"],
        ["Bloodurea", str(kidney_test.bloodurea), "Male: 13-17 g/dL, Female: 12-15 g/dL"],
        ["Serumcreatinine", str(kidney_test.serumcreatinine), "Male: 4.7-6.1 million/μL, Female: 4.2-5.4 million/μL"],
        ["Bun", str(kidney_test.bun), "150,000-450,000 /μL"],
        ["Uricacid", str(kidney_test.uricacid), "Male: 40-54%, Female: 36-48%"],
        ["Other Test", kidney_test.other_test, "Refer to specifics"],
        ["Result", kidney_test.result, "Refer to specifics"],
        ["Normal_Value", str(kidney_test.normal_value), "27-31 pg"],
        ["Remarks", kidney_test.remarks, "N/A"],
    ]

    test_table = Table(test_info, colWidths=[130, 100, 280])
    test_table.setStyle(TableStyle([
        ('ALIGN', (0, 0), (-1, 0), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
        ('FONTSIZE', (0, 0), (-1, -1), 12),  # Reduced font size for test details
        ('GRID', (0, 0), (-1, -1), 0.3, colors.grey),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
    ]))
    elements.append(test_table)

    elements.append(Spacer(1, 8))

    # Signature section
       # Signature section aligned to the right
    signature_data = [
        ["", "Signature"]  # Empty cell on the left and "Signature" on the right
    ]
    signature_table = Table(signature_data, colWidths=[400, 100])  # Adjust the width as necessary
    signature_table.setStyle(TableStyle([
        ('ALIGN', (1, 0), (1, 0), 'RIGHT'),  # Align "Signature" text to the right
        ('FONTNAME', (1, 0), (1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (1, 0), (1, 0), 20),  # Set font size for "Signature"
        ('TOPPADDING', (0, 0), (-1, -1), 20),  # Add padding at the top for space
    ]))

    # Add the signature table to elements
    elements.append(signature_table)

    # Build the PDF
    pdf.build(elements)

    return response

# Urine
def addurine(request):
    # Get the next test ID for the Urine test
    max_test_id = Urine.objects.aggregate(Max('test_id'))['test_id__max']
    next_test_id = (max_test_id + 1) if max_test_id is not None else 1

    # Fetch all patients from the PatientMaster model
    patients = PatientMaster.objects.all()

    if request.method == 'POST':
        form = UrineForm(request.POST)
        if form.is_valid():
            patient_id = request.POST.get('patient_id')  # Get patient_id from the form
            try:
                # Fetch the PatientMaster instance using the patient_id
                patient = PatientMaster.objects.get(pk=patient_id)

                # Fetch the Doctor instance from the patient's refbydoctor field
                doctor = patient.refbydoctor  # Get the doctor from the patient's refbydoctor field

                # Create a Urine instance without saving it yet
                urine_test = form.save(commit=False)
                urine_test.test_id = next_test_id
                urine_test.patient = patient
                urine_test.doctor = doctor  # Assign the doctor

                # Populate the Urine instance with data from PatientMaster
                urine_test.patientname = patient.patientname
                urine_test.age = patient.age
                urine_test.gender = patient.gender
                urine_test.mobile = patient.mobile
                urine_test.email = patient.email

                # Save the Urine instance
                urine_test.save()

                # Update the next_test_id for the form
                next_test_id += 1

                messages.success(request, 'Urine test added successfully.')
                form = UrineForm(initial={'test_id': next_test_id})
                return render(request, 'addurine.html', {'form': form, 'next_test_id': next_test_id, 'patients': patients})
            except PatientMaster.DoesNotExist:
                messages.error(request, 'Patient ID not found.')
            except Exception as e:
                messages.error(request, f'An error occurred: {str(e)}')
    else:
        # For GET requests, initialize the form with the next_test_id
        form = UrineForm(initial={'test_id': next_test_id})

    return render(request, 'addurine.html', {'form': form, 'next_test_id': next_test_id, 'patients': patients})


def generate_urine_pdf(urine_test, buffer):
    pdf = SimpleDocTemplate(buffer, pagesize=letter)
    styles = getSampleStyleSheet()
    elements = []

    # Add Pathology Center Title
    title = Paragraph("Sur Pathology Station Road Durg", styles['Title'])
    elements.append(title)
    elements.append(Spacer(1, 12))

    # Add Pathology Logo if available
    logo_path = os.path.join(settings.BASE_DIR, 'pathoapp', 'static', 'images', 'logo.png')
    if os.path.exists(logo_path):
        logo = Image(logo_path, width=80, height=80)
        elements.append(logo)
        elements.append(Spacer(1, 12))

    # Add a horizontal line
    elements.append(Paragraph("<hr/>", styles['Normal']))
    elements.append(Spacer(1, 12))

    # Patient Information
    patient_info = [
        ["Patient Name:", urine_test.patient.patientname],
        ["Age:", str(urine_test.age)],
        ["Gender:", urine_test.gender],
        ["Mobile:", urine_test.mobile],
        ["Email:", urine_test.email if urine_test.email else "N/A"],
    ]
    patient_table = Table(patient_info, colWidths=[100, 200])
    patient_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 10),
    ]))
    elements.append(patient_table)
    elements.append(Spacer(1, 12))

    # Report Title
    report_title = Paragraph("Urine Test Report", styles['Title'])
    elements.append(report_title)
    elements.append(Spacer(1, 12))

    # Test Details
    test_info = [
        ["Test ID:", str(urine_test.test_id)],
        ["Test Date:", urine_test.test_date.strftime("%Y-%m-%d") if urine_test.test_date else "N/A"],
        ["Colour:", f"{urine_test.colour} g/dL" if urine_test.colour else "N/A"],
        ["Appearance:", f"{urine_test.appearance} million/μL" if urine_test.appearance else "N/A"],
        ["Sediment:", f"{urine_test.sediment} /μL" if urine_test.sediment else "N/A"],
        ["Reaction:", f"{urine_test.reaction} %" if urine_test.reaction else "N/A"],
        ["Albumin:", f"{urine_test.albumin} fL" if urine_test.albumin else "N/A"],
        ["Sugar:", f"{urine_test.sugar} pg" if urine_test.sugar else "N/A"],
        ["Puscells:", f"{urine_test.puscells} g/dL" if urine_test.puscells else "N/A"],
        ["Rbc:", f"{urine_test.rbc} %" if urine_test.rbc else "N/A"],
        ["Epithelialcells:", f"{urine_test.epithelialcells} min" if urine_test.epithelialcells else "N/A"],
        ["Bilesalt:", f"{urine_test.bilesalt} min" if urine_test.bilesalt else "N/A"],
        ["Aceyone:", urine_test.aceyone if urine_test.aceyone else "N/A"],
        ["casts:",urine_test.casts if urine_test.casts else "N/A"],
        ["crystals:", f"{urine_test.crystals} min" if urine_test.crystals else "N/A"],
        ["microorganism:", urine_test.microorganism if urine_test.microorganism else "N/A"],
        ["bilepigment:",urine_test.bilepigment if urine_test.bilepigment else "N/A"],
        ["Occultblood:", f"{urine_test.occultblood} min" if urine_test.occultblood else "N/A"],
        ["Aceyone:", urine_test.aceyone if urine_test.aceyone else "N/A"],
        ["Other Test:", urine_test.other_test if urine_test.other_test else "N/A"],
        ["other_test_result:", urine_test.other_test_result if urine_test.other_test_result else "N/A"],
        
        ["Remarks:", urine_test.remarks if urine_test.remarks else "None"],
    ]
    test_table = Table(test_info, colWidths=[150, 250])
    test_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 10),
    ]))
    elements.append(test_table)
    elements.append(Spacer(1, 12))

    # Signature Section
    elements.append(Spacer(1, 20))
    elements.append(Paragraph("Signature:", styles['Normal']))
    elements.append(Spacer(1, 40))

    # Generate PDF
    pdf.build(elements)



def viewurine(request):
    # Fetch all Urine tests from the database
    urine_test = Urine.objects.all()

    # Pass the test data to the template for rendering
    return render(request, 'viewurine.html', {
        'urine_tests': urine_test
    })

def updateurine(request, test_id):
    # Fetch the Urine test instance or show a 404 page if not found
    urine_test = get_object_or_404(Urine, test_id=test_id)

    if request.method == 'POST':
        # Bind form to POST data
        form = UrineForm(request.POST, instance=urine_test)
        if form.is_valid():
            # Save the updated test if the form is valid
            form.save()
            messages.success(request, 'Data Updated Successfully.')
            return redirect('viewurine')
        else:
            # Add form errors to the context for debugging
            messages.error(request, 'Please correct the errors below.')
            print("Form Errors:", form.errors)  # Debugging information
    else:
        # Pre-populate the form with existing instance data
        form = UrineForm(instance=urine_test)

    # Fetch the patient information from the PatientMaster associated with the Haematology test
    patient_data = urine_test.patient  # Get the associated PatientMaster instance

    # Pre-fill the form with the patient's ID (as this can be changed)
    form.fields['patient_id'].initial = patient_data.patientid  # Assign initial patient ID value
    
    # Fetch additional data (refbydoctor and doctor_email) from PatientMaster
    patient_data.refbydoctor = patient_data.refbydoctor  # Fetch referred doctor name
    patient_data.email = patient_data.email  # Fetch doctor email

    # Render the update form template with the form and patient data
    return render(request, 'updateurine.html', {
        'form': form,
        'test_id': test_id,
        'patient_data': patient_data  # Pass the patient data to the template
    })


def deleteurine(request, test_id):
    # Get the Haematology test record to be deleted
    urine_test = get_object_or_404(Urine, test_id=test_id)
    
    # Delete the record
    urine_test.delete()
    
    # Add a success message
    messages.success(request, 'Urine test deleted successfully.')
    
    # Redirect to the view page
    return redirect('viewurine')


def generate_urine_report(request, test_id):
   # Fetch the kidney record using the test_id
    try:
        urine_test = Urine.objects.get(test_id=test_id)
    except Urine.DoesNotExist:
        return HttpResponse("Urine test not found.", content_type='text/plain')

    # Fetch the pathology center information
    pathology_info = Pathoinfo.objects.first()

    # Create a PDF response
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="urine_report_{test_id}.pdf"'

    # Create a PDF document
    pdf = SimpleDocTemplate(response, pagesize=letter)
    styles = getSampleStyleSheet()
    elements = []

    # Add logo with reduced size
    logo_path = os.path.join(settings.BASE_DIR, 'pathoapp', 'static', 'images', 'logo.png')
    if os.path.exists(logo_path):
        logo = Image(logo_path, width=80, height=80)  # Reduced size
        elements.append(logo)
    else:
        elements.append(Paragraph("Logo image not found", styles['Normal']))

    # Add pathology center information, single centered table
    if pathology_info:
        pathology_info_data = [
            [pathology_info.name],
            [f"Address: {pathology_info.add1}, {pathology_info.add2}, {pathology_info.city}"],
            [f"Mobile: {pathology_info.mobile}"],
            [f"Terms: {pathology_info.term1}"],
        ]
        pathology_table = Table(pathology_info_data, colWidths=[400])
        pathology_table.setStyle(TableStyle([
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 12),  # Reduced font size
            ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
            ('TOPPADDING', (0, 0), (-1, -1), 3),
        ]))
        elements.append(pathology_table)
    else:
        elements.append(Paragraph("Pathology Center Information Not Available", styles['Normal']))

    elements.append(Spacer(1, 8))

    # Patient details in a single-row table with compact spacing
    patient_info = [
        ["Test ID", "Test Date", "Patient Name", "Age", "Mobile", ],
        [str(urine_test.test_id),urine_test.test_date,urine_test.patient.patientname,  urine_test.age, 
         urine_test.mobile, ]
    ]
    patient_table = Table(patient_info, colWidths=[60, 100, 100, 60, 80])
    patient_table.setStyle(TableStyle([
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
        ('FONTSIZE', (0, 0), (-1, -1), 12),  # Smaller font for compactness
        ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
        ('GRID', (0, 0), (-1, -1), 0.3, colors.grey),
    ]))
    elements.append(patient_table)

    elements.append(Spacer(1, 8))

    # Report title with a smaller font size
    report_title = Paragraph("Blood Sugar Test Report", styles['Title'])
    report_title.style.fontSize = 14  # Slightly reduced font size
    elements.append(report_title)
    elements.append(Spacer(1, 8))

    # Blood Sugar test details in a three-column layout
    test_info = [
        ["Investigation", "Patient's Value", "Normal Value"],
        ["Colour", str(urine_test.colour), "Male: 13-17 g/dL, Female: 12-15 g/dL"],
        ["Appearance", str(urine_test.appearance), "Male: 4.7-6.1 million/μL, Female: 4.2-5.4 million/μL"],
        ["Sediment", str(urine_test.sediment), "150,000-450,000 /μL"],
        ["Reaction", str(urine_test.reaction), "Male: 40-54%, Female: 36-48%"],
        ["Albumin", str(urine_test.albumin), "27-31 pg"],
        ["Sugar", str(urine_test.sugar), "32-36 g/dL"],
        ["Puscells", str(urine_test.puscells), "0.5-2.5%"],
        ["Rbc", str(urine_test.rbc), "Male: 13-17 g/dL, Female: 12-15 g/dL"],
        ["Epithelialcells", str(urine_test.epithelialcells), "Male: 4.7-6.1 million/μL, Female: 4.2-5.4 million/μL"],
        ["Bilesalt", str(urine_test.bilesalt), "150,000-450,000 /μL"],
        ["Aceyone", str(urine_test.aceyone), "Male: 40-54%, Female: 36-48%"],
        ["Bilepigment", str(urine_test.bilepigment), "150,000-450,000 /μL"],
        ["Occultblood", str(urine_test.occultblood), "Male: 40-54%, Female: 36-48%"],
        ["Casts", str(urine_test.casts), "27-31 pg"],
        ["Crystals", str(urine_test.crystals), "32-36 g/dL"],
        ["Microorganism", str(urine_test.microorganism), "0.5-2.5%"],
        ["Other Test", urine_test.other_test, "Refer to specifics"],
        ["Other_test_result", urine_test.other_test_result, "Refer to specifics"],
        ["Remarks", urine_test.remarks, "N/A"],
    ]

    test_table = Table(test_info, colWidths=[130, 100, 280])
    test_table.setStyle(TableStyle([
        ('ALIGN', (0, 0), (-1, 0), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
        ('FONTSIZE', (0, 0), (-1, -1), 12),  # Reduced font size for test details
        ('GRID', (0, 0), (-1, -1), 0.3, colors.grey),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
    ]))
    elements.append(test_table)

    elements.append(Spacer(1, 8))

    # Signature section
       # Signature section aligned to the right
    signature_data = [
        ["", "Signature"]  # Empty cell on the left and "Signature" on the right
    ]
    signature_table = Table(signature_data, colWidths=[400, 100])  # Adjust the width as necessary
    signature_table.setStyle(TableStyle([
        ('ALIGN', (1, 0), (1, 0), 'RIGHT'),  # Align "Signature" text to the right
        ('FONTNAME', (1, 0), (1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (1, 0), (1, 0), 20),  # Set font size for "Signature"
        ('TOPPADDING', (0, 0), (-1, -1), 20),  # Add padding at the top for space
    ]))

    # Add the signature table to elements
    elements.append(signature_table)


    # Build the PDF
    pdf.build(elements)

    return response



def tests_on_date(request, date=None):
    if not date:
        date = timezone.now().strftime('%Y-%m-%d')  # Default to today's date
    tests = Test.objects.filter(test_date=date)
    test_count = tests.count()
    return render(request, 'tests_on_date.html', {'date': date, 'test_count': test_count, 'tests': tests})


def addhiv(request):
    # Get the next test ID for the Hiv test
    max_test_id = Hiv.objects.aggregate(Max('test_id'))['test_id__max']
    next_test_id = (max_test_id + 1) if max_test_id is not None else 1

    # Fetch all patients from the PatientMaster model
    patients = PatientMaster.objects.all()

    if request.method == 'POST':
        form = HivForm(request.POST)
        if form.is_valid():
            patient_id = request.POST.get('patient_id')  # Get patient_id from the form
            try:
                # Fetch the PatientMaster instance using the patient_id
                patient = PatientMaster.objects.get(pk=patient_id)

                # Fetch the Doctor instance from the patient's refbydoctor field
                doctor = patient.refbydoctor  # Get the doctor from the patient's refbydoctor field

                # Create a Hiv instance without saving it yet
                hiv_test = form.save(commit=False)
                hiv_test.test_id = next_test_id
                hiv_test.patient = patient
                hiv_test.doctor = doctor  # Assign the doctor

                # Populate the Hiv instance with data from PatientMaster
                hiv_test.patientname = patient.patientname
                hiv_test.age = patient.age
                hiv_test.gender = patient.gender
                hiv_test.mobile = patient.mobile
                hiv_test.email = patient.email

                # Save the Hiv instance
                hiv_test.save()

                # Update the next_test_id for the form
                next_test_id += 1

                messages.success(request, 'Hiv test added successfully.')
                form = HivForm(initial={'test_id': next_test_id})
                return render(request, 'addhiv.html', {'form': form, 'next_test_id': next_test_id, 'patients': patients})
            except PatientMaster.DoesNotExist:
                messages.error(request, 'Patient ID not found.')
            except Exception as e:
                messages.error(request, f'An error occurred: {str(e)}')
    else:
        # For GET requests, initialize the form with the next_test_id
        form = HivForm(initial={'test_id': next_test_id})

    return render(request, 'addhiv.html', {'form': form, 'next_test_id': next_test_id, 'patients': patients})

# Utility function to generate the PDF

def generate_hiv_pdf(hiv_test, buffer):
    pdf = SimpleDocTemplate(buffer, pagesize=letter)
    styles = getSampleStyleSheet()
    elements = []

    # Add Pathology Center Title
    title = Paragraph("Sur Pathology Station Road Durg", styles['Title'])
    elements.append(title)
    elements.append(Spacer(1, 12))

    # Add Pathology Logo if available
    logo_path = os.path.join(settings.BASE_DIR, 'pathoapp', 'static', 'images', 'logo.png')
    if os.path.exists(logo_path):
        logo = Image(logo_path, width=80, height=80)
        elements.append(logo)
        elements.append(Spacer(1, 12))

    # Add a horizontal line
    elements.append(Paragraph("<hr/>", styles['Normal']))
    elements.append(Spacer(1, 12))

    # Patient Information
    patient_info = [
        ["Patient Name:", hiv_test.patient.patientname],
        ["Age:", str( hiv_test.age)],
        ["Gender:", hiv_test.gender],
        ["Mobile:", hiv_test.mobile],
        ["Email:",  hiv_test.email if hiv_test.email else "N/A"],
    ]
    patient_table = Table(patient_info, colWidths=[100, 200])
    patient_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 10),
    ]))
    elements.append(patient_table)
    elements.append(Spacer(1, 12))

    # Report Title
    report_title = Paragraph("Haematology Test Report", styles['Title'])
    elements.append(report_title)
    elements.append(Spacer(1, 12))

    # Test Details
    test_info = [
        ["Test ID:", str(hiv_test.test_id)],
        ["Test Date:", hiv_test.test_date.strftime("%Y-%m-%d") if hiv_test.test_date else "N/A"],
        ["Haemoglobin:", f"{hiv_test.haemoglobin} g/dL" if hiv_test.haemoglobin else "N/A"],
        ["Other Test:", hiv_test.other_test if hiv_test.other_test else "N/A"],
        ["Result:", hiv_test.result if hiv_test.result else "N/A"],
        ["Normal Value:", hiv_test.normal_value if hiv_test.normal_value else "Refer to specifics"],
        ["Remarks:", hiv_test.remarks if hiv_test.remarks else "None"],
    ]
    test_table = Table(test_info, colWidths=[150, 250])
    test_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 10),
    ]))
    elements.append(test_table)
    elements.append(Spacer(1, 12))

    # Signature Section
    elements.append(Spacer(1, 20))
    elements.append(Paragraph("Signature:", styles['Normal']))
    elements.append(Spacer(1, 40))

    # Generate PDF
    pdf.build(elements)



def viewhiv(request):
    # Fetch all Hiv tests from the database
    hiv_tests = Hiv.objects.all()

    # Pass the test data to the template for rendering
    return render(request, 'viewhiv.html', {
        'hiv_tests': hiv_tests
    })

def updatehiv(request, test_id):
    # Fetch the Haematology test instance or show a 404 page if not found
    hiv_test = get_object_or_404(Hiv, test_id=test_id)

    if request.method == 'POST':
        # Bind form to POST data
        form = HaematologyForm(request.POST, instance=hiv_test)
        if form.is_valid():
            # Save the updated test if the form is valid
            form.save()
            messages.success(request, 'Data Updated Successfully.')
            return redirect('viewhiv')
        else:
            # Add form errors to the context for debugging
            messages.error(request, 'Please correct the errors below.')
            print("Form Errors:", form.errors)  # Debugging information
    else:
        # Pre-populate the form with existing instance data
        form = HivForm(instance=hiv_test)

    # Fetch the patient information from the PatientMaster associated with the Haematology test
    patient_data = hiv_test.patient  # Get the associated PatientMaster instance

    # Pre-fill the form with the patient's ID (as this can be changed)
    form.fields['patient_id'].initial = patient_data.patientid  # Assign initial patient ID value
    
    # Fetch additional data (refbydoctor and doctor_email) from PatientMaster
    patient_data.refbydoctor = patient_data.refbydoctor  # Fetch referred doctor name
    patient_data.email = patient_data.email  # Fetch doctor email

    # Render the update form template with the form and patient data
    return render(request, 'updatehiv.html', {
        'form': form,
        'test_id': test_id,
        'patient_data': patient_data  # Pass the patient data to the template
    })


def deletehiv(request, test_id):
    # Get the Hiv test record to be deleted
    hiv_test = get_object_or_404(Hiv, test_id=test_id)
    
    # Delete the record
    hiv_test.delete()
    
    # Add a success message
    messages.success(request, 'HIV test deleted successfully.')
    
    # Redirect to the view page
    return redirect('viewhiv')

def generate_hiv_report(request, test_id):
    # Fetch the hiv record using the test_id
    try:
        hiv_test = Hiv.objects.get(test_id=test_id)
    except Hiv.DoesNotExist:
        return HttpResponse("HIV test not found.", content_type='text/plain')

    # Fetch the pathology center information
    pathology_info = Pathoinfo.objects.first()

    # Create a PDF response
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="hiv_report_{test_id}.pdf"'

    # Create a PDF document
    pdf = SimpleDocTemplate(response, pagesize=letter)
    styles = getSampleStyleSheet()
    elements = []

    # Add logo with reduced size
    logo_path = os.path.join(settings.BASE_DIR, 'pathoapp', 'static', 'images', 'logo.png')
    if os.path.exists(logo_path):
        logo = Image(logo_path, width=80, height=80)  # Reduced size
        elements.append(logo)
    else:
        elements.append(Paragraph("Logo image not found", styles['Normal']))

    # Add pathology center information, single centered table
    if pathology_info:
        pathology_info_data = [
            [pathology_info.name],
            [f"Address: {pathology_info.add1}, {pathology_info.add2}, {pathology_info.city}"],
            [f"Mobile: {pathology_info.mobile}"],
            [f"Terms: {pathology_info.term1}"],
        ]
        pathology_table = Table(pathology_info_data, colWidths=[400])
        pathology_table.setStyle(TableStyle([
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 12),  # Reduced font size
            ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
            ('TOPPADDING', (0, 0), (-1, -1), 3),
        ]))
        elements.append(pathology_table)
    else:
        elements.append(Paragraph("Pathology Center Information Not Available", styles['Normal']))

    elements.append(Spacer(1, 8))

    # Patient details in a single-row table with compact spacing
    patient_info = [
        ["Test ID", "Test Date", "Patient Name", "Age", "Mobile", ],
        [str(hiv_test.test_id),hiv_test.test_date,hiv_test.patient.patientname,  hiv_test.age, 
         hiv_test.mobile, ]
    ]
    patient_table = Table(patient_info, colWidths=[60, 100, 100, 60, 80])
    patient_table.setStyle(TableStyle([
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
        ('FONTSIZE', (0, 0), (-1, -1), 12),  # Smaller font for compactness
        ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
        ('GRID', (0, 0), (-1, -1), 0.3, colors.grey),
    ]))
    elements.append(patient_table)

    elements.append(Spacer(1, 8))

    # Report title with a smaller font size
    report_title = Paragraph("HIV Test Report", styles['Title'])
    report_title.style.fontSize = 14  # Slightly reduced font size
    elements.append(report_title)
    elements.append(Spacer(1, 8))

    # Haematology test details in a three-column layout
    test_info = [
        ["Investigation", "Patient's Value", "Normal Value"],
        ["Hiv", str(hiv_test.haemoglobin), "Male: 13-17 g/dL, Female: 12-15 g/dL"],
        ["Other Test", hiv_test.other_test, "Refer to specifics"],
        ["Result", hiv_test.result, "Refer to specifics"],
        ["Normal Value:", hiv_test.normal_value,"Refer to specifics"],
        ["Remarks", hiv_test.remarks, "N/A"],
    ]

    test_table = Table(test_info, colWidths=[130, 100, 280])
    test_table.setStyle(TableStyle([
        ('ALIGN', (0, 0), (-1, 0), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
        ('FONTSIZE', (0, 0), (-1, -1), 12),  # Reduced font size for test details
        ('GRID', (0, 0), (-1, -1), 0.3, colors.grey),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
    ]))
    elements.append(test_table)

    elements.append(Spacer(1, 8))

    # Signature section
       # Signature section aligned to the right
    signature_data = [
        ["", "Signature"]  # Empty cell on the left and "Signature" on the right
    ]
    signature_table = Table(signature_data, colWidths=[400, 100])  # Adjust the width as necessary
    signature_table.setStyle(TableStyle([
        ('ALIGN', (1, 0), (1, 0), 'RIGHT'),  # Align "Signature" text to the right
        ('FONTNAME', (1, 0), (1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (1, 0), (1, 0), 20),  # Set font size for "Signature"
        ('TOPPADDING', (0, 0), (-1, -1), 20),  # Add padding at the top for space
    ]))

    # Add the signature table to elements
    elements.append(signature_table)
    # Build the PDF
    pdf.build(elements)

    return response


def addmicroalbumin(request):
   # Get the next test ID for the Microalbumin test
    max_test_id = Microalbumin.objects.aggregate(Max('test_id'))['test_id__max']
    next_test_id = (max_test_id + 1) if max_test_id is not None else 1

    # Fetch all patients from the PatientMaster model
    patients = PatientMaster.objects.all()

    if request.method == 'POST':
        form = MicroalbuminForm(request.POST)
        if form.is_valid():
            patient_id = request.POST.get('patient_id')  # Get patient_id from the form
            try:
                # Fetch the PatientMaster instance using the patient_id
                patient = PatientMaster.objects.get(pk=patient_id)

                # Fetch the Doctor instance from the patient's refbydoctor field
                doctor = patient.refbydoctor  # Get the doctor from the patient's refbydoctor field

                # Create a Microalbumin instance without saving it yet
                microalbumin_test = form.save(commit=False)
                microalbumin_test.test_id = next_test_id
                microalbumin_test.patient = patient
                microalbumin_test.doctor = doctor  # Assign the doctor

                # Populate the Microalbumin instance with data from PatientMaster
                microalbumin_test.patientname = patient.patientname
                microalbumin_test.age = patient.age
                microalbumin_test.gender = patient.gender
                microalbumin_test.mobile = patient.mobile
                microalbumin_test.email = patient.email

                # Save the Microalbumin instance
                microalbumin_test.save()

                # Update the next_test_id for the form
                next_test_id += 1

                messages.success(request, 'Microalbumin test added successfully.')
                form = MicroalbuminForm(initial={'test_id': next_test_id})
                return render(request, 'addmicroalbumin.html', {'form': form, 'next_test_id': next_test_id, 'patients': patients})
            except PatientMaster.DoesNotExist:
                messages.error(request, 'Patient ID not found.')
            except Exception as e:
                messages.error(request, f'An error occurred: {str(e)}')
    else:
        # For GET requests, initialize the form with the next_test_id
        form = MicroalbuminForm(initial={'test_id': next_test_id})

    return render(request, 'addmicroalbumin.html', {'form': form, 'next_test_id': next_test_id, 'patients': patients})


# Utility function to generate the PDF
def generate_microalbumin_pdf(microalbumin_test, buffer):
    pdf = SimpleDocTemplate(buffer, pagesize=letter)
    styles = getSampleStyleSheet()
    elements = []

    # Add Pathology Center Title
    title = Paragraph("Sur Pathology Station Road Durg", styles['Title'])
    elements.append(title)
    elements.append(Spacer(1, 12))

    # Add Pathology Logo if available
    logo_path = os.path.join(settings.BASE_DIR, 'pathoapp', 'static', 'images', 'logo.png')
    if os.path.exists(logo_path):
        logo = Image(logo_path, width=80, height=80)
        elements.append(logo)
        elements.append(Spacer(1, 12))

    # Add a horizontal line
    elements.append(Paragraph("<hr/>", styles['Normal']))
    elements.append(Spacer(1, 12))

    # Patient Information
    patient_info = [
        ["Patient Name:", microalbumin_test.patient.patientname],
        ["Age:", str(microalbumin_test.age)],
        ["Gender:", microalbumin_test.gender],
        ["Mobile:", microalbumin_test.mobile],
        ["Email:", microalbumin_test.email if microalbumin_test.email else "N/A"],
    ]
    patient_table = Table(patient_info, colWidths=[100, 200])
    patient_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 10),
    ]))
    elements.append(patient_table)
    elements.append(Spacer(1, 12))

    # Report Title
    report_title = Paragraph("Haematology Test Report", styles['Title'])
    elements.append(report_title)
    elements.append(Spacer(1, 12))

    # Test Details
    test_info = [
        ["Test ID:", str(microalbumin_test.test_id)],
        ["Test Date:", microalbumin_test.test_date.strftime("%Y-%m-%d") if microalbumin_test.test_date else "N/A"],
        ["Colour:", f"{microalbumin_test.colour} g/dL" if microalbumin_test.colour else "N/A"],
        ["clarity:", f"{microalbumin_test.clarity} million/μL" if microalbumin_test.clarity else "N/A"],
        ["Albumin:", f"{microalbumin_test.albumin} /μL" if microalbumin_test.albumin else "N/A"],
        ["Creatine:", f"{microalbumin_test.creatine} %" if microalbumin_test.creatine else "N/A"],
        ["Acratio:", f"{microalbumin_test.acratio} fL" if microalbumin_test.acratio else "N/A"],
        ["Other Test:", microalbumin_test.other_test if microalbumin_test.other_test else "N/A"],
        ["Result:", microalbumin_test.result if microalbumin_test.result else "N/A"],
        ["Normal Value:", microalbumin_test.normal_value if microalbumin_test.normal_value else "Refer to specifics"],
        ["Remark:", microalbumin_test.remark if microalbumin_test.remark else "None"],
    ]
    test_table = Table(test_info, colWidths=[150, 250])
    test_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 10),
    ]))
    elements.append(test_table)
    elements.append(Spacer(1, 12))

    # Signature Section
    elements.append(Spacer(1, 20))
    elements.append(Paragraph("Signature:", styles['Normal']))
    elements.append(Spacer(1, 40))

    # Generate PDF
    pdf.build(elements)




def viewmicroalbumin(request):
    # Fetch all Haematology tests from the database
    microalbumin_tests = Microalbumin.objects.all()

    # Pass the test data to the template for rendering
    return render(request, 'viewmicroalbumin.html', {
        'microalbumin_tests': microalbumin_tests
    })

def updatemicroalbumin(request, test_id):
    # Fetch the Haematology test instance or show a 404 page if not found
    microalbumin_test = get_object_or_404(Microalbumin, test_id=test_id)

    if request.method == 'POST':
        # Bind form to POST data
        form = MicroalbuminForm(request.POST, instance=microalbumin_test)
        if form.is_valid():
            # Save the updated test if the form is valid
            form.save()
            messages.success(request, 'Data Updated Successfully.')
            return redirect('viewmicroalbumin')
        else:
            # Add form errors to the context for debugging
            messages.error(request, 'Please correct the errors below.')
            print("Form Errors:", form.errors)  # Debugging information
    else:
        # Pre-populate the form with existing instance data
        form = MicroalbuminForm(instance=microalbumin_test)

    # Fetch the patient information from the PatientMaster associated with the Haematology test
    patient_data = microalbumin_test.patient  # Get the associated PatientMaster instance

    # Pre-fill the form with the patient's ID (as this can be changed)
    form.fields['patient_id'].initial = patient_data.patientid  # Assign initial patient ID value
    
    # Fetch additional data (refbydoctor and doctor_email) from PatientMaster
    patient_data.refbydoctor = patient_data.refbydoctor  # Fetch referred doctor name
    patient_data.email = patient_data.email  # Fetch doctor email

    # Render the update form template with the form and patient data
    return render(request, 'updatemicroalbumin.html', {
        'form': form,
        'test_id': test_id,
        'patient_data': patient_data  # Pass the patient data to the template
    })


def deletemicroalbumin(request, test_id):
    # Get the Haematology test record to be deleted
    microalbumin_test = get_object_or_404(Microalbumin, test_id=test_id)
    
    # Delete the record
    microalbumin_test.delete()
    
    # Add a success message
    messages.success(request, 'Microalbumin test deleted successfully.')
    
    # Redirect to the view page
    return redirect('viewmicroalbumin')


def generate_microalbumin_report(request, test_id):
    # Fetch the haematology record using the test_id
    try:
        microalbumin_test = Microalbumin.objects.get(test_id=test_id)
    except Microalbumin.DoesNotExist:
        return HttpResponse("Microalbumin test not found.", content_type='text/plain')

    # Fetch the pathology center information
    pathology_info = Pathoinfo.objects.first()

    # Create a PDF response
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="microalbumin_report_{test_id}.pdf"'

    # Create a PDF document
    pdf = SimpleDocTemplate(response, pagesize=letter)
    styles = getSampleStyleSheet()
    elements = []

    # Add logo with reduced size
    logo_path = os.path.join(settings.BASE_DIR, 'pathoapp', 'static', 'images', 'logo.png')
    if os.path.exists(logo_path):
        logo = Image(logo_path, width=80, height=80)  # Reduced size
        elements.append(logo)
    else:
        elements.append(Paragraph("Logo image not found", styles['Normal']))

    # Add pathology center information, single centered table
    if pathology_info:
        pathology_info_data = [
            [pathology_info.name],
            [f"Address: {pathology_info.add1}, {pathology_info.add2}, {pathology_info.city}"],
            [f"Mobile: {pathology_info.mobile}"],
            [f"Terms: {pathology_info.term1}"],
        ]
        pathology_table = Table(pathology_info_data, colWidths=[400])
        pathology_table.setStyle(TableStyle([
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 12),  # Reduced font size
            ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
            ('TOPPADDING', (0, 0), (-1, -1), 3),
        ]))
        elements.append(pathology_table)
    else:
        elements.append(Paragraph("Pathology Center Information Not Available", styles['Normal']))

    elements.append(Spacer(1, 8))

    # Patient details in a single-row table with compact spacing
    patient_info = [
        ["Test ID", "Test Date", "Patient Name", "Age", "Mobile", ],
        [str(microalbumin_test.test_id),microalbumin_test.test_date,microalbumin_test.patient.patientname,  microalbumin_test.age, 
         microalbumin_test.mobile, ]
    ]
    patient_table = Table(patient_info, colWidths=[60, 100, 100, 60, 80])
    patient_table.setStyle(TableStyle([
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
        ('FONTSIZE', (0, 0), (-1, -1), 12),  # Smaller font for compactness
        ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
        ('GRID', (0, 0), (-1, -1), 0.3, colors.grey),
    ]))
    elements.append(patient_table)

    elements.append(Spacer(1, 8))

    # Report title with a smaller font size
    report_title = Paragraph("Microalbumin Test Report", styles['Title'])
    report_title.style.fontSize = 14  # Slightly reduced font size
    elements.append(report_title)
    elements.append(Spacer(1, 8))

    # Haematology test details in a three-column layout
    test_info = [
        ["Investigation", "Patient's Value", "Normal Value"],
        
        ["Colour", str(microalbumin_test.colour), "Male: 13-17 g/dL, Female: 12-15 g/dL"],
        ["clarity", str(microalbumin_test.clarity), "Male: 4.7-6.1 million/μL, Female: 4.2-5.4 million/μL"],
        ["Albumin", str(microalbumin_test.lbumin), "150,000-450,000 /μL"],
        ["Creatine", str(microalbumin_test.creatine), "Male: 40-54%, Female: 36-48%"],
        ["Acratio", str(microalbumin_test.acratio), "80-100 fL"],
       ["Other Test", microalbumin_test.other_test, "Refer to specifics"],
        ["Result", microalbumin_test.result, "Refer to specifics"],
        ["Remark", microalbumin_test.remark, "N/A"],
    ]

    test_table = Table(test_info, colWidths=[130, 100, 280])
    test_table.setStyle(TableStyle([
        ('ALIGN', (0, 0), (-1, 0), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
        ('FONTSIZE', (0, 0), (-1, -1), 12),  # Reduced font size for test details
        ('GRID', (0, 0), (-1, -1), 0.3, colors.grey),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
    ]))
    elements.append(test_table)

    elements.append(Spacer(1, 8))

    # Signature section
       # Signature section aligned to the right
    signature_data = [
        ["", "Signature"]  # Empty cell on the left and "Signature" on the right
    ]
    signature_table = Table(signature_data, colWidths=[400, 100])  # Adjust the width as necessary
    signature_table.setStyle(TableStyle([
        ('ALIGN', (1, 0), (1, 0), 'RIGHT'),  # Align "Signature" text to the right
        ('FONTNAME', (1, 0), (1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (1, 0), (1, 0), 20),  # Set font size for "Signature"
        ('TOPPADDING', (0, 0), (-1, -1), 20),  # Add padding at the top for space
    ]))

    # Add the signature table to elements
    elements.append(signature_table)

    # Build the PDF
    pdf.build(elements)
    return response

def doctor_st(request):
     # Initialize variables
    doctors = Doctor.objects.all()
    selected_doctor = None
    tests = []

    if request.method == 'POST':
        # Get selected doctor's name from the form
        doctorname = request.POST.get('doctorname')
        if doctorname:
            selected_doctor = Doctor.objects.get(doctorname=doctorname)
            # Fetch tests conducted by the selected doctor
            tests = Haematology.objects.filter(doctor=selected_doctor)

    # Prepare context
    context = {
        'doctors': doctors,
        'selected_doctor': selected_doctor,
        'tests': tests,
    }

    return render(request, 'pathoapp/doctor_st.html', context)


def daily_report(request):
    # Initialize variables
    tests = []
    start_date = None
    end_date = None

    if request.method == 'POST':
        # Get start_date and end_date from the form
        start_date = request.POST.get('start_date')
        end_date = request.POST.get('end_date')

        # Fetch tests conducted within the selected date range
        if start_date and end_date:
            tests = Haematology.objects.filter(
                test_date__gte=start_date,
                test_date__lte=end_date
            )

    # Prepare context
    context = {
        'start_date': start_date,
        'end_date': end_date,
        'tests': tests,
    }

    return render(request, 'pathoapp/daily_report.html', context)
